﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TourOperator
{
    public class TourOperator
    {
        private String nextClientCode;
        Dictionary<String,Client> dizionario = new Dictionary<String, Client>(); // dichiaro dizionarii
        public TourOperator(String initialClientCode) // metodo costruttore
        {
            this.nextClientCode = initialClientCode;
        }
        public void add(String nome, String dest) // metodo per aggiungere
        {
            Client cliente = new Client(nome,dest);

            dizionario.Add(nextClientCode, cliente); //inserisco dentro al dizionario i valori che passo nei parametri del metodo

            int numero = 0, carattere; // controllo per codice
            numero += Convert.ToInt32(nextClientCode[3]);
            numero += Convert.ToInt32(nextClientCode[2])*10; 
            numero += Convert.ToInt32(nextClientCode[1]) * 100;
            carattere = Convert.ToInt32(nextClientCode[0]);

            if (numero == 999) // Se il mio cliente è il n°999 incremento il carattere per ripartire da zero
                nextClientCode = Convert.ToChar(carattere++) + "000";
            else // incremento numeri
            {
                numero++;
                nextClientCode = Convert.ToChar(carattere) + Convert.ToString(numero);
            }
        }
        public String toString() // metodo per restituire i valori del dizionario
        {
            return $"{dizionario.ElementAt(0)}:"; // 
        }

        public static void main(String[] args)  // Il metodo istanzia un oggetto di classe TourOperator, inserisce valori e li mostra a video
        {
            TourOperator tour = new TourOperator(Console.ReadLine());
            String name;
            String dest;
            name = Console.ReadLine();
            dest = Console.ReadLine();

            tour.add(name, dest);

            Console.WriteLine(tour.toString());
        }

        // classi interne
        private class Client
        {
            String name; // nome del cliente
            String dest; // destinazione del viaggio
            public Client(String aName, String aDest)
            {
                name = aName;
                dest = aDest;
            }
        }
        private class Coppia
        {
            String code;
            Client client;
            Coppia(String aCode, Client aClient)
            {
                code = aCode;
                client = aClient;
            }

            public bool compareTo(Object obj)
            {
                Coppia tmpC = (Coppia)obj;
                return code.Equals(tmpC.code);

            }
        }
    }
}
