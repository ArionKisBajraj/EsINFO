﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TourOperator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TourOperator tour = new TourOperator(Console.ReadLine());
            String name;
            String dest;
            name = Console.ReadLine();
            dest = Console.ReadLine();

            tour.add(name, dest);

            Console.WriteLine(tour.toString());
            Console.ReadLine();
        }
    }
}
