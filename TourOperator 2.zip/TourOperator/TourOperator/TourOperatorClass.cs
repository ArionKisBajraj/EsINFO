﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TourOperator
{
    public class TourOperator
    {
        private String ClienteSuccessivo;
        Dictionary<String,Client> dizionario = new Dictionary<String, Client>(); 
        public TourOperator(String PrimoCliente) 
        {
            this.ClienteSuccessivo = PrimoCliente;
        }
        public void add(String nome, String dest) 
        {
            Client cliente = new Client(nome,dest);

            dizionario.Add(ClienteSuccessivo, cliente); //aggiungo un cliente all'interno del dizionario

            int numero = 0, carattere;                          //Inserimento del codice
            numero += Convert.ToInt32(ClienteSuccessivo[3]);       //Inserimento del codice
            numero += Convert.ToInt32(ClienteSuccessivo[2])*10;    //Inserimento del codice
            numero += Convert.ToInt32(ClienteSuccessivo[1]) * 100; //Inserimento del codice
            carattere = Convert.ToInt32(ClienteSuccessivo[0]);     //Inserimento del codice

            if (numero == 999) // Se il mio cliente è il n°999 incremento il carattere per ripartire da zero
                ClienteSuccessivo = Convert.ToChar(carattere++) + "000"; //passo al carattere successivo e azzero i numeri
            else 
            {
                numero++;// incremento numeri
                ClienteSuccessivo = Convert.ToChar(carattere) + Convert.ToString(numero);
            }
        }
        public String toString() // metodo per restituire i valori del dizionario
        {
            return $"{dizionario.ElementAt(0)}:"; // 
        }

        public static void main(String[] args)  // Il metodo istanzia un oggetto di classe TourOperator, inserisce valori e li mostra a video
        {
            TourOperator tour = new TourOperator(Console.ReadLine());
            String nome;
            String dest;
            nome = Console.ReadLine();
            dest = Console.ReadLine();

            tour.add(nome, dest);

            Console.WriteLine(tour.toString());
        }

        // classi interne
        private class Client
        {
            String nome; // nome del cliente
            String dest; // destinazione del viaggio
            public Client(String aName, String aDest)
            {
                nome = aName;
                dest = aDest;
            }
        }
        private class Coppia
        {
            String code;
            Client client;
            Coppia(String aCode, Client aClient)
            {
                code = aCode;
                client = aClient;
            }

            public bool compareTo(Object obj)
            {
                Coppia tmpC = (Coppia)obj;
                return code.Equals(tmpC.code);

            }
        }
    }
}
